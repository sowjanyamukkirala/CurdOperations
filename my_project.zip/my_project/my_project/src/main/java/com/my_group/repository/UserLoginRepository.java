package com.my_group.repository;

import com.my_group.model.AdminRegistration;
import com.my_group.model.UserLogin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLoginRepository extends JpaRepository<UserLogin, Long> {

}
