package com.my_group.controller;

import com.my_group.model.AdminRegistration;
import com.my_group.model.UserLogin;
import com.my_group.model.UserRegistration;
import com.my_group.service.UserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserLoginController {
    @Autowired
    UserLoginService userLoginService;
    @GetMapping("/user")
    public List<UserLogin> getAll(){
        List<UserLogin> users = userLoginService.getAll();
        return users;
    }

    @GetMapping("/{id}")
    public Optional<UserLogin> getAdminById(@PathVariable Long id)
    {

        return userLoginService.findById(id);
    }

    @PostMapping("/add_Users")
    public UserLogin addUser(@RequestBody UserLogin userLogin){
        userLoginService.addUser(userLogin);
        return userLogin;

    }
}
