package com.my_group.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "AdminRegistration")
@Getter
@Setter

public class AdminRegistration {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String first_name;
    private String last_name;
    private String email;
    private String phone_no;

}
