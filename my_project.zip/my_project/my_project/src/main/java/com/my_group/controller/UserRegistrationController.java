package com.my_group.controller;

import com.my_group.model.UserRegistration;
import com.my_group.service.UserRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/userregistration")
public class UserRegistrationController
{
    @Autowired
    UserRegistrationService userRegService;
    @GetMapping("/getAll")
    public List<UserRegistration> getAll(){
    List<UserRegistration> usr = userRegService.getAll();
    return usr;
    }
    @GetMapping("/{id}")
    public Optional<UserRegistration> getUserById(@PathVariable Long id)
    {
        return userRegService.findById(id);
    }
    @PostMapping("/addRegistration")
    public UserRegistration addUserReg(@RequestBody UserRegistration userRegistration){
        userRegService.addUserReg(userRegistration);
        return userRegistration;
    }


}

