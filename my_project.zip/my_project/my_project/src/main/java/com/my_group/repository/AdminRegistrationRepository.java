package com.my_group.repository;

import com.my_group.model.AdminRegistration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRegistrationRepository extends JpaRepository<AdminRegistration, Long> {
}
