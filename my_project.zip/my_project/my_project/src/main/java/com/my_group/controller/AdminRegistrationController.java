package com.my_group.controller;

import com.my_group.model.AdminRegistration;
import com.my_group.model.UserLogin;
import com.my_group.service.AdminRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/adminregistration")
public class AdminRegistrationController
{
 @Autowired
 AdminRegistrationService adminRegistrationService;
    @GetMapping("/getAll")
    public List<AdminRegistration> getAll(){
        List<AdminRegistration> ad1 = adminRegistrationService.getAll();
        return ad1;
    }
    @GetMapping("/{id}")
    public Optional<AdminRegistration> getAdminById(@PathVariable Long id)
    {

        return adminRegistrationService.findById(id);
    }

    @PostMapping("/addDetails")
    public AdminRegistration addreg(@RequestBody AdminRegistration adminRegistration){
        return adminRegistrationService.addReg(adminRegistration);
    }

}
