package com.my_group.controller;

import com.my_group.model.AdminLogin;
import com.my_group.model.AdminRegistration;
import com.my_group.service.AdminLoginService;
import com.my_group.service.AdminRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Adminlogin")
public class AdminLoginController {
    @Autowired
    AdminLoginService adminLoginService;
    @GetMapping("/login")
    public List<AdminLogin> getAll(){
        List<AdminLogin> users = adminLoginService.getAll();
        return users;
    }
    @GetMapping("/{id}")
    public Optional<AdminLogin> getAdminById(@PathVariable Long id)
    {
        return adminLoginService.findById(id);
    }

    @PostMapping("/addAdmin")
    public AdminLogin addAdmin(@RequestBody AdminLogin adminLogin){
        adminLoginService.addAdmin(adminLogin);
        return adminLogin;

    }

}


